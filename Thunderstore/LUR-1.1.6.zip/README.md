# Join the new Lethal Upgrades Program!

We heard some employees could not complete their quotas, complaining and exclaiming
"oh it's just not fair!" blah blah...

After we fed them to **[THE COMPANY]** though, we got to thinking... \
What if we DID give them upgrades? \
And now here we are!

They come at a cost, but we can offer you the chance to **[FEED HIM MORE]**
while powering you up! \
Seems fair... *right?*

## Currently Offering
Health - Take a few more thumper hits!
- Tier 1: Gain +20 additional health.
- Tier 2: Reduce all incoming damage by 5%. 
- Tier 3: Gain +30 additional health. 

Stamina - More items carried, more **[FEEDING IT]**
- Tier 1: Decrease running stamina usage. 
- Tier 2: Improve stamina regen by 10%. 
- Tier 3: Reduced stamina penalties when heavy (>=50 lbs). 
- Legendary: When damaged, regardless of amount or source, gain full stamina back. 

Movement - Run away from that vile giant.
- Tier 1: Sprint 6% faster.
- Tier 2: Walk/Crouch 12% faster.
- Tier 3: Increased jump height by 25%. 

## To-be Offered

Utility - You don't need these really.
- Tier 1: Increase all battery capacities by 10%.
- Tier 2: Reduce cost of all store items by 10%. 
- Tier 3: Flashlight items can pass through the inverse teleporter.

Legendaries 
- Health: Gain an adaptive regeneration abality.
    + If you are below 50% health, gain +0.5 hp/s regen until back up to 50%.
    + If you are below 100% but above 50% health and have not taken damage again 20 seconds after the first time, gain a passive + 2 hp/s buff until back up to 100%. Can be stopped if taking damage again.
- Movement: While critically injured, become invisible.
- Utilities: All equipment weighs 0 pounds. 

# General Information

On a side note, welcome to the Lethal Upgrades mod! \
Trying to bring less stagnation and more gameplay diversity through this mod. \
Upgrades are usually focused on different categories that benefit the player. \
These upgrades either take credits or use tokens, such as the legendary ones! \
Upgrades are *progressive*, meaning they need to be bought in order.

<details>
    <summary> <b>Token System [SPOILERS]</b> </summary>
    Tokens are acquired by cummulative performances on the moons you go to!<br>
    In other words, how fast or slow you get a token depends on your performance!<br>
    <br>
    The mod uses a "token meter" which starts at 0 and goes up to 100.<br>
    Depending on your performance grade, the meter fills up a certain amount.<br>
    Once you reach 100, you get a token to claim a legendary upgrade!<br>
    <br>
    The amount per grade is as follows:
    <ul>
        <li> <b> Rank S: 50 </b> </li>
        <li> <b> Rank A: 35 </b> </li>
        <li> <b> Rank B: 10 </b> </li>
        <li> <b> Rank C: 5 </b> </li>
        <li> <b> Rank F: -10 </b> </li>
    </ul>
</details>

## Terminal Commands and Extra Information

Command Table for Upgrades (Some may not be implemented yet)

| Category | Tier 1               | Tier 2               | Tier 3               | Legendary                | Info                    |
|----------|----------------------|----------------------|----------------------|--------------------------|-------------------------|
| Health   | `upgrade health 1`   | `upgrade health 2`   | `upgrade health 3`   | `upgrade token health`   | `upgrade health info`   |
| Stamina  | `upgrade stamina 1`  | `upgrade stamina 2`  | `upgrade stamina 3`  | `upgrade token stamina`  | `upgrade stamina info`  |
| Movement | `upgrade movement 1` | `upgrade movement 2` | `upgrade movement 3` | `upgrade token movement` | `upgrade movement info` |
| Utility  | `upgrade utility 1`  | `upgrade utility 2`  | `upgrade utility 3`  | `upgrade token utility`  | `upgrade utility info`  |

Cost Table for Upgrades
| Category | Tier 1 | Tier 2 | Tier 3 | Legendary |
|----------|--------|--------|--------|-----------|
| Health   | $200    | $300    | $400    | 1 token   |
| Stamina  | $300    | $400    | $500    | 1 token   |
| Movement | $200    | $300    | $350    | 1 token   |
| Utility  | $300    | $450    | $500    | 1 token   |

Extra Commands
| Command                 | Description                                   |
|-------------------------|-----------------------------------------------|
| `upgrade`               | Brief explanation of the mod.                 |
| `upgrade token`         | Brief explanation on upgrade tokens.          |
| `upgrade health info`   | Summarizes health upgrades and their costs.   |
| `upgrade stamina info`  | Summarizes stamina upgrades and their costs.  |
| `upgrade movement info` | Summarizes movement upgrades and their costs. |
| `upgrade utility info`  | Summarizes utility upgrades and their costs.  |

## Multiplayer Status

MULTIPLAYER STATUS: 🟢
- 🔴 Not working
- 🟡 Testing
- 🟢 Operational

## Bugs

Please report any bugs, specially multiplayer ones, to try and patch them ASAP. \
Still a WIP, so bare with me. I plan to add more in the future.